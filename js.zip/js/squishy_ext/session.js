function UserSession() {
	
}
Session.prototype=Object.create(UserModel)
Session.prototype={
	
};
